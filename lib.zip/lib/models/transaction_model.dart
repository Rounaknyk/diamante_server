import 'package:flutter/material.dart';

class TransModel{

  String source_account, create_date, operation_type, funder_account;

  TransModel({this.source_account = '', this.create_date = '', this.funder_account = '', this.operation_type = ''});
}
