import 'package:flutter/material.dart';

class ViewTransactionTab extends StatefulWidget {
  const ViewTransactionTab({super.key});

  @override
  State<ViewTransactionTab> createState() => _ViewTransactionTabState();
}

class _ViewTransactionTabState extends State<ViewTransactionTab> {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Text('BKL!'),
      );
  }
}
